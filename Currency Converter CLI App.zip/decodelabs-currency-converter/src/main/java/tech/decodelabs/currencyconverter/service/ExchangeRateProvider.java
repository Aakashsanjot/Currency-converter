package tech.decodelabs.currencyconverter.service;

import tech.decodelabs.currencyconverter.model.Currency;

import java.math.BigDecimal;

/**
 * Supplies the exchange rate of a given {@link Currency} relative to a
 * single pivot currency (USD).
 * <p>
 * This abstraction is what lets the engine be scaled from Project 4's
 * "static, hardcoded values" stage to the "Turbocharger" enterprise stage
 * without touching a single line of the conversion logic itself — only the
 * provider implementation changes. See {@link StaticExchangeRateProvider}
 * for the offline implementation and {@link LiveExchangeRateProvider} for
 * the live REST API implementation.
 */
public interface ExchangeRateProvider {

    /**
     * @param currency the currency whose USD-relative rate is requested
     * @return how many units of {@code currency} equal 1 USD
     */
    BigDecimal getRate(Currency currency);

    /**
     * @return a short label describing where the rates come from, used for
     *         on-screen feedback (e.g. "Static Offline Rates" or
     *         "Live Rates (exchangerate-api.com)").
     */
    String getSourceLabel();
}
