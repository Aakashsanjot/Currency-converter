package tech.decodelabs.currencyconverter.exception;

/**
 * Thrown by the Security Gate whenever the user supplies a monetary amount
 * that cannot be processed safely — most notably, a negative value.
 * <p>
 * Money can never be negative in this engine. Rather than letting a
 * negative number silently flow into the Combustion Engine and produce a
 * nonsensical converted value, we fail loudly and route the user straight
 * back to the main menu.
 */
public class InvalidAmountException extends RuntimeException {

    public InvalidAmountException(String message) {
        super(message);
    }
}
