package tech.decodelabs.currencyconverter.util;

import tech.decodelabs.currencyconverter.model.Currency;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * The Exhaust stage — turns a raw {@link BigDecimal} into a
 * presentation-ready financial string.
 * <p>
 * Enforces exactly two decimal places and thousands-grouping commas, so
 * the underlying floating-point-free precision from the Combustion Engine
 * is never undermined by sloppy display formatting.
 */
public final class CurrencyFormatter {

    private CurrencyFormatter() {
        // Utility class — not instantiable.
    }

    /**
     * Formats an amount with its currency symbol, thousands separators and
     * exactly two decimal places, e.g. {@code $ 8,350.00}.
     */
    public static String format(BigDecimal amount, Currency currency) {
        BigDecimal polished = amount.setScale(2, RoundingMode.HALF_EVEN);
        return String.format("%s %,10.2f", currency.getSymbol(), polished);
    }

    /**
     * Formats a bare amount (no symbol) with exactly two decimal places
     * and thousands separators, e.g. {@code 8,350.00}.
     */
    public static String formatPlain(BigDecimal amount) {
        BigDecimal polished = amount.setScale(2, RoundingMode.HALF_EVEN);
        return String.format("%,.2f", polished);
    }
}
