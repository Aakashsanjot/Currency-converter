package tech.decodelabs.currencyconverter.service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import tech.decodelabs.currencyconverter.model.Currency;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.Map;

/**
 * The "Turbocharger" stage of Project 4 — connects to a live REST API
 * (exchangerate-api.com) instead of relying on hardcoded values.
 * <p>
 * Pipeline, matching the four stages described in the project brief:
 * <ol>
 *   <li><b>URL Construction</b> — inject the API key into the endpoint string.</li>
 *   <li><b>Connection Management</b> — open {@link HttpURLConnection}, method GET.</li>
 *   <li><b>Response Verification</b> — confirm HTTP 200 before proceeding.</li>
 *   <li><b>Data Extraction</b> — stream the body, then drill into the JSON
 *       {@code conversion_rates} object with GSON to pull out each rate.</li>
 * </ol>
 * Rates are cached for the lifetime of this provider instance so that a
 * single menu session does not hammer the API with a fresh request for
 * every currency lookup.
 */
public class LiveExchangeRateProvider implements ExchangeRateProvider {

    private static final String ENDPOINT_TEMPLATE =
            "https://v6.exchangerate-api.com/v6/%s/latest/USD";

    private final String apiKey;
    private final Map<Currency, BigDecimal> cachedRates = new EnumMap<>(Currency.class);
    private boolean fetched = false;

    public LiveExchangeRateProvider(String apiKey) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalArgumentException(
                    "An exchangerate-api.com API key is required for live rates. "
                            + "Set the EXCHANGE_RATE_API_KEY environment variable.");
        }
        this.apiKey = apiKey;
    }

    @Override
    public BigDecimal getRate(Currency currency) {
        if (!fetched) {
            fetchLiveRates();
        }
        BigDecimal rate = cachedRates.get(currency);
        if (rate == null) {
            throw new IllegalStateException("Live rate not available for " + currency);
        }
        return rate;
    }

    @Override
    public String getSourceLabel() {
        return "Live Rates (exchangerate-api.com)";
    }

    /**
     * Performs the full URL Construction -> Connection Management ->
     * Response Verification -> Data Extraction pipeline exactly once,
     * populating {@link #cachedRates} for every {@link Currency} we support.
     */
    private void fetchLiveRates() {
        try {
            // --- 1. URL Construction ---
            String endpoint = String.format(ENDPOINT_TEMPLATE, apiKey);
            URL url = URI.create(endpoint).toURL();

            // --- 2. Connection Management ---
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);

            // --- 3. Response Verification ---
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw new IOException("Exchange rate API returned HTTP " + responseCode);
            }

            // --- 4. Data Extraction ---
            String rawJson = readBody(connection.getInputStream());
            JsonObject root = JsonParser.parseString(rawJson).getAsJsonObject();
            JsonObject conversionRates = root.getAsJsonObject("conversion_rates");

            for (Currency currency : Currency.values()) {
                if (conversionRates.has(currency.name())) {
                    double rateValue = conversionRates.get(currency.name()).getAsDouble();
                    // Convert through String, never through the raw double,
                    // to avoid re-introducing binary floating-point noise.
                    cachedRates.put(currency, new BigDecimal(Double.toString(rateValue)));
                }
            }
            fetched = true;

        } catch (IOException e) {
            throw new RuntimeException(
                    "Could not reach the live exchange rate service: " + e.getMessage(), e);
        }
    }

    private String readBody(InputStream inputStream) throws IOException {
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }
        }
        return builder.toString();
    }
}
