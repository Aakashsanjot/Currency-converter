package tech.decodelabs.currencyconverter.service;

import tech.decodelabs.currencyconverter.model.Currency;

import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.Map;

/**
 * The "Rate Input" stage of Project 4 — a static, hardcoded table of
 * exchange rates, all expressed relative to a single pivot currency, USD.
 * <p>
 * Every rate is constructed from a {@link String}, never a {@code double}
 * literal, which is exactly what keeps the engine free of binary
 * floating-point contamination from the moment the number is born.
 */
public class StaticExchangeRateProvider implements ExchangeRateProvider {

    private final Map<Currency, BigDecimal> ratesAgainstUsd;

    public StaticExchangeRateProvider() {
        this.ratesAgainstUsd = new EnumMap<>(Currency.class);
        // Approximate reference rates (units of currency per 1 USD).
        ratesAgainstUsd.put(Currency.USD, new BigDecimal("1"));
        ratesAgainstUsd.put(Currency.INR, new BigDecimal("83.4128"));
        ratesAgainstUsd.put(Currency.PKR, new BigDecimal("278.50"));
        ratesAgainstUsd.put(Currency.EUR, new BigDecimal("0.9241"));
        ratesAgainstUsd.put(Currency.GBP, new BigDecimal("0.7891"));
        ratesAgainstUsd.put(Currency.JPY, new BigDecimal("157.23"));
        ratesAgainstUsd.put(Currency.AUD, new BigDecimal("1.5023"));
        ratesAgainstUsd.put(Currency.CAD, new BigDecimal("1.3689"));
    }

    @Override
    public BigDecimal getRate(Currency currency) {
        BigDecimal rate = ratesAgainstUsd.get(currency);
        if (rate == null) {
            throw new IllegalStateException("No static rate configured for " + currency);
        }
        return rate;
    }

    @Override
    public String getSourceLabel() {
        return "Static Offline Rates (Project 4 baseline)";
    }
}
