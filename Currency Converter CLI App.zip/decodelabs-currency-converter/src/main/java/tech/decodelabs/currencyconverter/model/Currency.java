package tech.decodelabs.currencyconverter.model;

/**
 * Enumerates every currency supported by the Financial Translation Engine.
 * <p>
 * Each constant carries its ISO 4217 code (the enum name itself), a
 * human-readable display name and a printable symbol. Keeping this data
 * inside the enum means the rest of the codebase never has to juggle raw
 * strings when referring to a currency, which eliminates an entire class
 * of typo-driven bugs.
 */
public enum Currency {

    USD("US Dollar", "$"),
    INR("Indian Rupee", "₹"),
    PKR("Pakistani Rupee", "Rs"),
    EUR("Euro", "€"),
    GBP("British Pound", "£"),
    JPY("Japanese Yen", "¥"),
    AUD("Australian Dollar", "A$"),
    CAD("Canadian Dollar", "C$");

    private final String displayName;
    private final String symbol;

    Currency(String displayName, String symbol) {
        this.displayName = displayName;
        this.symbol = symbol;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getSymbol() {
        return symbol;
    }

    /**
     * Safely resolves a {@link Currency} from user-typed text.
     *
     * @param code the raw text typed by the user (case-insensitive, trimmed)
     * @return the matching Currency
     * @throws IllegalArgumentException if the code does not match any supported currency
     */
    public static Currency fromCode(String code) {
        if (code == null) {
            throw new IllegalArgumentException("Currency code cannot be null.");
        }
        return Currency.valueOf(code.trim().toUpperCase());
    }
}
