package tech.decodelabs.currencyconverter.core;

import tech.decodelabs.currencyconverter.exception.InvalidAmountException;
import tech.decodelabs.currencyconverter.model.Currency;
import tech.decodelabs.currencyconverter.service.ExchangeRateProvider;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * The Combustion Engine — the mathematical heart of the Financial
 * Translation Engine.
 * <p>
 * Every calculation here is performed with {@link BigDecimal}, never
 * {@code double}. This is a deliberate, non-negotiable design decision:
 * {@code double} uses IEEE-754 binary floating point, which cannot exactly
 * represent most base-10 decimals (famously, {@code 0.1 + 0.2 == 0.30000000000000004}).
 * In financial software that error compounds across millions of
 * transactions into real, measurable monetary loss. {@link BigDecimal}
 * performs arbitrary-precision, base-10-accurate arithmetic instead.
 * <p>
 * Rounding uses {@link RoundingMode#HALF_EVEN} ("Banker's Rounding")
 * throughout, which eliminates the statistical upward bias that
 * {@code HALF_UP} rounding introduces across large datasets.
 */
public class CurrencyConverter {

    /** Extra guard digits kept during the intermediate pivot division. */
    private static final MathContext INTERMEDIATE_PRECISION = new MathContext(20, RoundingMode.HALF_EVEN);

    /** Every monetary amount is finally presented with exactly this many decimal places. */
    private static final int FINAL_SCALE = 2;

    private final ExchangeRateProvider rateProvider;

    public CurrencyConverter(ExchangeRateProvider rateProvider) {
        this.rateProvider = rateProvider;
    }

    /**
     * Converts {@code amount} from {@code source} currency to {@code target}
     * currency via cross-rate routing through the USD pivot.
     * <p>
     * Flow: source -> USD (intermediate value) -> target (final value).
     * When source or target is USD itself, this collapses naturally into a
     * single direct multiplication/division — no special-casing required.
     *
     * @param amount the monetary amount to convert; must not be negative
     * @param source the currency the amount is currently denominated in
     * @param target the currency to convert into
     * @return the converted amount, rounded to exactly 2 decimal places
     * @throws InvalidAmountException if amount is negative
     */
    public BigDecimal convert(BigDecimal amount, Currency source, Currency target) {
        validateAmount(amount);

        BigDecimal sourceRate = rateProvider.getRate(source); // units of `source` per 1 USD
        BigDecimal targetRate = rateProvider.getRate(target); // units of `target` per 1 USD

        // Step 1: source -> USD (the intermediate/pivot value)
        BigDecimal amountInUsd = amount.divide(sourceRate, INTERMEDIATE_PRECISION);

        // Step 2: USD -> target (the final value)
        BigDecimal converted = amountInUsd.multiply(targetRate);

        // Final financial polish: exactly two decimal places, Banker's rounding.
        return converted.setScale(FINAL_SCALE, RoundingMode.HALF_EVEN);
    }

    /**
     * The Security Gate. Rejects negative amounts before they ever reach
     * the arithmetic pipeline, per the project's defensive-programming
     * requirement.
     */
    private void validateAmount(BigDecimal amount) {
        if (amount == null) {
            throw new InvalidAmountException("Amount cannot be null.");
        }
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new InvalidAmountException(
                    "Negative amounts are not permitted. Please enter a positive value.");
        }
    }

    public String getRateSourceLabel() {
        return rateProvider.getSourceLabel();
    }
}
