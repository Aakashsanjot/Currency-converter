package tech.decodelabs.currencyconverter;

import tech.decodelabs.currencyconverter.core.CurrencyConverter;
import tech.decodelabs.currencyconverter.exception.InvalidAmountException;
import tech.decodelabs.currencyconverter.model.Currency;
import tech.decodelabs.currencyconverter.service.ExchangeRateProvider;
import tech.decodelabs.currencyconverter.service.LiveExchangeRateProvider;
import tech.decodelabs.currencyconverter.service.StaticExchangeRateProvider;
import tech.decodelabs.currencyconverter.util.CurrencyFormatter;
import tech.decodelabs.currencyconverter.util.InputHandler;

import java.io.PrintStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * DecodeLabs Industrial Training Kit — Java Programming Project 4.
 * <p>
 * "The Financial Translation Engine": an enterprise-grade console currency
 * converter demonstrating precise (BigDecimal-based) arithmetic, defensive
 * input handling, a do-while/switch driven menu, and an optional live REST
 * API integration for real-time exchange rates.
 * <p>
 * Run with {@code java -jar currency-converter.jar} after building with
 * Maven (see README.md for full instructions).
 */
public class Main {

    private static final int OPTION_CONVERT_STATIC = 1;
    private static final int OPTION_CONVERT_LIVE = 2;
    private static final int OPTION_VIEW_RATES = 3;
    private static final int OPTION_EXIT = 4;

    public static void main(String[] args) {
        // Ensure currency symbols (₹, €, £, ¥, ...) always render correctly,
        // regardless of the host platform's default console charset.
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));

        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        InputHandler inputHandler = new InputHandler(scanner);
        ExchangeRateProvider staticProvider = new StaticExchangeRateProvider();

        printBanner();

        int choice;
        // The do-while loop guarantees the menu body executes at least once
        // and keeps restarting the application until the user explicitly exits.
        do {
            printMenu();
            choice = inputHandler.readMenuChoice("Enter your choice: ", OPTION_CONVERT_STATIC, OPTION_EXIT);

            // The switch board — replaces a cluttered if-else chain and
            // routes each menu choice to its handler, with a default case
            // that traps any unexpected value.
            switch (choice) {
                case OPTION_CONVERT_STATIC:
                    runConversion(inputHandler, staticProvider);
                    break;

                case OPTION_CONVERT_LIVE:
                    runLiveConversion(inputHandler);
                    break;

                case OPTION_VIEW_RATES:
                    printSupportedCurrencies(staticProvider);
                    break;

                case OPTION_EXIT:
                    System.out.println("\nThank you for using the DecodeLabs Financial Translation Engine.");
                    System.out.println("Handle data with precision. Goodbye!\n");
                    break;

                default:
                    // Unreachable in practice because InputHandler already
                    // clamps the range, but kept as a defensive trap.
                    System.out.println("Invalid menu choice. Please try again.");
            }

        } while (choice != OPTION_EXIT);

        scanner.close();
    }

    /**
     * Handles a single conversion request end to end using whichever
     * {@link ExchangeRateProvider} is supplied (static or live). The
     * Security Gate is enforced inside {@link CurrencyConverter}, and any
     * {@link InvalidAmountException} is caught here so a bad amount routes
     * the user straight back to the menu instead of crashing the app.
     */
    private static void runConversion(InputHandler inputHandler, ExchangeRateProvider provider) {
        try {
            CurrencyConverter converter = new CurrencyConverter(provider);

            Currency source = inputHandler.readCurrency("Enter source currency (e.g. USD): ");
            Currency target = inputHandler.readCurrency("Enter target currency (e.g. INR): ");
            BigDecimal amount = inputHandler.readAmount("Enter amount to convert: ");

            BigDecimal result = converter.convert(amount, source, target);

            System.out.println("\n--- Conversion Result (" + converter.getRateSourceLabel() + ") ---");
            System.out.println("Source Amount   : " + CurrencyFormatter.format(amount, source));
            System.out.println("Converted Amount: " + CurrencyFormatter.format(result, target));
            System.out.println("------------------------------------------------------------\n");

        } catch (InvalidAmountException e) {
            System.out.println("\n[Security Gate] " + e.getMessage());
            System.out.println("Returning to main menu.\n");
        }
    }

    /**
     * Attempts to build a {@link LiveExchangeRateProvider} from the
     * {@code EXCHANGE_RATE_API_KEY} environment variable. If the key is
     * missing or the live service is unreachable, the user is informed and
     * gracefully returned to the menu instead of crashing the application.
     */
    private static void runLiveConversion(InputHandler inputHandler) {
        String apiKey = System.getenv("EXCHANGE_RATE_API_KEY");
        if (apiKey == null || apiKey.isBlank()) {
            System.out.println("\n[Turbocharger] No API key found.");
            System.out.println("Set the EXCHANGE_RATE_API_KEY environment variable with your");
            System.out.println("exchangerate-api.com key to enable live rates. Falling back to");
            System.out.println("static rates is available from the main menu (option 1).\n");
            return;
        }

        try {
            ExchangeRateProvider liveProvider = new LiveExchangeRateProvider(apiKey);
            runConversion(inputHandler, liveProvider);
        } catch (RuntimeException e) {
            System.out.println("\n[Turbocharger] Live rate lookup failed: " + e.getMessage());
            System.out.println("Please check your internet connection and API key, or use the");
            System.out.println("static rates option instead.\n");
        }
    }

    private static void printBanner() {
        System.out.println("==============================================================");
        System.out.println("   DecodeLabs Industrial Training Kit -- Java Project 4");
        System.out.println("   The Financial Translation Engine (Currency Converter)");
        System.out.println("==============================================================");
    }

    private static void printMenu() {
        System.out.println("\nMain Menu:");
        System.out.println("  1. Convert Currency (Static Rates)");
        System.out.println("  2. Convert Currency (Live Rates - requires API key)");
        System.out.println("  3. View Supported Currencies & Static Rates");
        System.out.println("  4. Exit");
    }

    private static void printSupportedCurrencies(ExchangeRateProvider provider) {
        System.out.println("\nSupported Currencies (rate = units per 1 USD):");
        System.out.printf("  %-4s %-20s %-6s %s%n", "Code", "Name", "Symbol", "Rate vs USD");
        for (Currency currency : Currency.values()) {
            System.out.printf("  %-4s %-20s %-6s %s%n",
                    currency.name(),
                    currency.getDisplayName(),
                    currency.getSymbol(),
                    CurrencyFormatter.formatPlain(provider.getRate(currency)));
        }
        System.out.println();
    }
}
