package tech.decodelabs.currencyconverter.util;

import tech.decodelabs.currencyconverter.model.Currency;

import java.math.BigDecimal;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Wraps a {@link Scanner} and defends every read against the two classic
 * console-input failure modes described in the project brief:
 * <ul>
 *   <li><b>The Buffer Trap</b> — if the user types a letter where a number
 *       is expected, {@code Scanner} throws {@link InputMismatchException}
 *       and leaves the bad token sitting in the buffer. Left unhandled,
 *       the next read immediately re-reads the same stuck token, causing
 *       an infinite loop. Every numeric read here is wrapped in a
 *       try-catch that calls {@code scanner.nextLine()} to flush the
 *       buffer before retrying.</li>
 *   <li><b>The Security Gate</b> — negative amounts are rejected with a
 *       friendly message rather than being allowed to reach the
 *       conversion engine.</li>
 * </ul>
 */
public class InputHandler {

    private final Scanner scanner;

    public InputHandler(Scanner scanner) {
        this.scanner = scanner;
    }

    /**
     * Repeatedly prompts until the user provides a valid, non-negative
     * {@link BigDecimal} amount. Never throws for bad input — it simply
     * keeps asking again.
     */
    public BigDecimal readAmount(String prompt) {
        while (true) {
            System.out.print(prompt);
            String token = scanner.nextLine().trim();
            try {
                BigDecimal amount = new BigDecimal(token);
                if (amount.compareTo(BigDecimal.ZERO) < 0) {
                    System.out.println("Amount cannot be negative. Please try again.");
                    continue;
                }
                return amount;
            } catch (NumberFormatException e) {
                // Equivalent to catching InputMismatchException when reading
                // directly with scanner.nextBigDecimal() / nextDouble() —
                // here the buffer never gets "stuck" in the first place
                // because we always consume a full line with nextLine().
                System.out.println("Please enter a valid number.");
            }
        }
    }

    /**
     * Repeatedly prompts until the user types a currency code that matches
     * one of the supported {@link Currency} constants.
     */
    public Currency readCurrency(String prompt) {
        while (true) {
            System.out.print(prompt);
            String token = scanner.nextLine().trim();
            try {
                return Currency.fromCode(token);
            } catch (IllegalArgumentException e) {
                System.out.println("Unknown currency code \"" + token
                        + "\". Type HELP to see supported codes, or try again.");
                if (token.equalsIgnoreCase("HELP")) {
                    printSupportedCurrencies();
                }
            }
        }
    }

    /**
     * Repeatedly prompts until the user enters an integer within
     * [min, max], inclusive. Used to drive the do-while menu's switch board.
     */
    public int readMenuChoice(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String token = scanner.nextLine().trim();
            try {
                int choice = Integer.parseInt(token);
                if (choice < min || choice > max) {
                    System.out.println("Please enter a number between " + min + " and " + max + ".");
                    continue;
                }
                return choice;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid menu number.");
            }
        }
    }

    private void printSupportedCurrencies() {
        System.out.println("Supported currencies:");
        for (Currency c : Currency.values()) {
            System.out.printf("  %-3s - %s (%s)%n", c.name(), c.getDisplayName(), c.getSymbol());
        }
    }
}
