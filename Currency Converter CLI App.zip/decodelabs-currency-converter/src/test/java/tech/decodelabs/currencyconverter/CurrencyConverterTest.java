package tech.decodelabs.currencyconverter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tech.decodelabs.currencyconverter.core.CurrencyConverter;
import tech.decodelabs.currencyconverter.exception.InvalidAmountException;
import tech.decodelabs.currencyconverter.model.Currency;
import tech.decodelabs.currencyconverter.service.ExchangeRateProvider;
import tech.decodelabs.currencyconverter.service.StaticExchangeRateProvider;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Validates the four checklist items from the project brief:
 * multi-currency cross-rate support, input integrity (negative rejection),
 * financial accuracy (BigDecimal precision), and two-decimal formatting.
 */
class CurrencyConverterTest {

    private CurrencyConverter converter;

    @BeforeEach
    void setUp() {
        ExchangeRateProvider provider = new StaticExchangeRateProvider();
        converter = new CurrencyConverter(provider);
    }

    @Test
    void directConversionFromUsdMatchesRate() {
        // 100 USD * 83.4128 INR/USD = 8341.28 INR
        BigDecimal result = converter.convert(new BigDecimal("100"), Currency.USD, Currency.INR);
        assertEquals(new BigDecimal("8341.28"), result);
    }

    @Test
    void convertingToTheSameCurrencyReturnsTheOriginalAmount() {
        BigDecimal result = converter.convert(new BigDecimal("250.50"), Currency.EUR, Currency.EUR);
        assertEquals(new BigDecimal("250.50"), result);
    }

    @Test
    void crossRateConversionRoutesThroughUsdPivot() {
        // EUR -> INR should equal (amount / EUR_rate) * INR_rate
        BigDecimal result = converter.convert(new BigDecimal("100"), Currency.EUR, Currency.INR);
        assertEquals(new BigDecimal("9026.38"), result);
    }

    @Test
    void negativeAmountIsRejectedBySecurityGate() {
        assertThrows(InvalidAmountException.class,
                () -> converter.convert(new BigDecimal("-50"), Currency.USD, Currency.INR));
    }

    @Test
    void resultIsAlwaysScaledToExactlyTwoDecimalPlaces() {
        BigDecimal result = converter.convert(new BigDecimal("1"), Currency.USD, Currency.JPY);
        assertEquals(2, result.scale());
    }

    @Test
    void zeroAmountIsAllowedAndReturnsZero() {
        BigDecimal result = converter.convert(BigDecimal.ZERO, Currency.USD, Currency.GBP);
        assertEquals(new BigDecimal("0.00"), result);
    }
}
