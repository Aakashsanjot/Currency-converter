# Upgrade Plan: DecodeLabs Currency Converter (20260718114517)

- **Generated**: 2026-07-18 11:45:00
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 26.0.1: /usr/lib/jvm/jdk-26.0.1-oracle-x64/bin (available)
- JDK 21: **<TO_BE_INSTALLED>** (required by Step 1 for target runtime compatibility)

**Build Tools**
- Maven 3.9.12: /usr/share/maven/bin (available)
- Maven Wrapper: not present

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260718114517
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime target: 21

## Technology Stack

| Technology/Dependency       | Current    | Min Compatible | Why Incompatible                                   |
| -------------------------- | ---------- | -------------- | -------------------------------------------------- |
| Java                       | 17         | 21             | User requested latest LTS runtime                  |
| Maven                      | 3.9.12     | 3.9.0          | Compatible with JDK 21 and current plugin versions |
| maven-compiler-plugin      | 3.13.0     | 3.11.0         | Supports `release` 21 and Java 21 compilation      |
| maven-surefire-plugin      | 3.2.5      | 3.0.0          | Compatible with JUnit 5 and modern JDKs            |
| Gson                       | 2.11.0     | 2.8.9          | No Java 21 incompatibility                         |
| JUnit Jupiter              | 5.10.2     | 5.8+           | Compatible with JDK 21                             |

## Derived Upgrades

- Update Maven compiler properties from Java 17 to Java 21 to satisfy target runtime goal.
- Maintain Maven build plugins because current plugin versions support Java 21.
- Add explicit JDK 21 installation in the environment because the local toolchain currently only exposes JDK 26.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| pom.xml | `<maven.compiler.source>` | 17 | upgrade | 21 | Project target runtime update |
| pom.xml | `<maven.compiler.target>` | 17 | upgrade | 21 | Project target runtime update |
| pom.xml | `maven-compiler-plugin` `<release>` | 17 | upgrade | 21 | Ensure compiled bytecode targets Java 21 |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| None identified | N/A | N/A | N/A | No source-level Jakarta/Java API migration required for this upgrade |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| pom.xml | `maven.compiler.source` | 17 | 21 | Upgrade compilation target |
| pom.xml | `maven.compiler.target` | 17 | 21 | Upgrade compilation target |
| pom.xml | `release` | 17 | 21 | Align bytecode with Java 21 |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None | N/A | N/A | N/A |

### Risks & Warnings

- **Runtime verification environment**: Local toolchain currently provides JDK 26 only. Step 1 installs JDK 21 and will use it for final verification. If installation is blocked, the build may still compile with JDK 26 but will not validate the actual target runtime.
- **Compiler release target**: Using `--release 21` with Maven is compatible, but the `maven-compiler-plugin` version must remain at a modern release, which is already satisfied.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Ensure required JDK 21 is available for actual target runtime compilation and verification.
  - **Changes to Make**: install JDK 21; confirm `java -version` and Maven availability.
  - **Verification**: `appmod-install-jdk(version: "21")`, `JAVA_HOME=<jdk21> mvn -v` expected successful output.

- Step 2: Baseline Verification
  - **Rationale**: Establish current project health before the upgrade and capture the existing compile/test baseline.
  - **Changes to Make**: none.
  - **Verification**: `JAVA_HOME=<jdk26 or jdk21> mvn clean test-compile -q && mvn clean test -q` expected success.

- Step 3: Upgrade Java target to 21
  - **Rationale**: Apply the runtime upgrade in the build configuration and verify the project still compiles and tests pass.
  - **Changes to Make**: update `pom.xml` Java properties and compiler release from 17 to 21.
  - **Verification**: `JAVA_HOME=<jdk21> mvn clean test-compile -q` expected success.

- Step 4: CVE Validation & Fix
  - **Rationale**: Scan direct dependencies for known vulnerabilities and fix any reported CVEs.
  - **Changes to Make**: update dependency versions only if CVEs are reported by direct dependencies.
  - **Verification**: `mvn dependency:list -DexcludeTransitive=true` plus `#appmod-validate-cves-for-java(...)` and re-run `mvn clean test-compile -q` after fixes.

- Step 5: Final Validation
  - **Rationale**: Confirm the upgraded project fully compiles and all tests pass on the target runtime.
  - **Changes to Make**: resolve any issues discovered during verification and ensure the final build is clean.
  - **Verification**: `JAVA_HOME=<jdk21> mvn clean test -q` expected success.
